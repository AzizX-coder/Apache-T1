import argparse
from agent import DatasetAgent

def main():
    parser = argparse.ArgumentParser(description="Ollama Autonomous Dataset Collection Agent")
    parser.add_argument(
        "--topic", 
        type=str, 
        help="The topic to research and collect data on.",
        required=False
    )
    parser.add_argument(
        "--model", 
        type=str, 
        default="glm-5:cloud", 
        help="The Ollama model to use. Must support tool calling."
    )
    
    args = parser.parse_args()
    
    topic = args.topic
    if not topic:
        topic = input("Enter the topic you want the agent to research: ").strip()
        
    if not topic:
        print("Error: Topic cannot be empty.")
        return

    print(f"Initializing DatasetAgent with model: {args.model}")
    print("Ensure Ollama is running and you have run 'ollama run <model>' at least once.")
    
    agent = DatasetAgent(model_name=args.model)
    agent.run(topic)

if __name__ == "__main__":
    main()
