import json
import os
from duckduckgo_search import DDGS
import requests
from bs4 import BeautifulSoup

def search_internet(query: str) -> str:
    """
    Searches the internet using DuckDuckGo for a given query and returns the results.
    
    Args:
        query: The search query string.
        
    Returns:
        A string representation of the topmost search results containing titles, snippets, and URLs.
    """
    try:
        results = DDGS().text(query, max_results=5)
        if not results:
            return "No search results found."
        
        output = "Search Results:\n"
        for i, res in enumerate(results, start=1):
            output += f"{i}. Title: {res.get('title')}\n"
            output += f"   Snippet: {res.get('body')}\n"
            output += f"   URL: {res.get('href')}\n\n"
        return output.strip()
    except Exception as e:
        return f"Error performing search: {str(e)}"

def scrape_website(url: str) -> str:
    """
    Scrapes a website to extract its main text content.
    
    Args:
        url: The URL of the website to scrape.
        
    Returns:
        The extracted main text content of the website.
    """
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, "html.parser")
        
        # Remove script and style elements
        for script in soup(["script", "style", "nav", "footer", "header"]):
            script.extract()
            
        text = soup.get_text(separator=' ', strip=True)
        # basic cleanup of multiple spaces
        text = ' '.join(text.split())
        
        # Trim very long text to avoid blowing up context window
        if len(text) > 8000:
            text = text[:8000] + "... [Content Truncated]"
            
        return text
    except Exception as e:
        return f"Error scraping website: {str(e)}"

def save_to_dataset(topic: str, content: str, source_url: str) -> str:
    """
    Saves a piece of extracted information to a local dataset.
    
    Args:
        topic: The topic or category of the information.
        content: The actual information or facts to save to the dataset.
        source_url: The URL where the information was found.
        
    Returns:
        A success or error message.
    """
    dataset_file = "dataset.jsonl"
    try:
        record = {
            "topic": topic,
            "content": content,
            "source_url": source_url
        }
        with open(dataset_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(record) + "\n")
        return f"Successfully saved dataset record to {dataset_file}."
    except Exception as e:
        return f"Error saving to dataset: {str(e)}"
