import json
from ollama import Client

# Import our custom tools
from tools import search_internet, scrape_website, save_to_dataset

class DatasetAgent:
    def __init__(self, model_name: str = "glm-5:cloud"):
        """
        Initializes the agent with the specified Ollama model.
        Note: The model MUST support tool calling.
        """
        self.client = Client()
        self.model_name = model_name
        self.available_tools = {
            "search_internet": search_internet,
            "scrape_website": scrape_website,
            "save_to_dataset": save_to_dataset
        }
        self.system_prompt = """You are an autonomous Research and Data Collection Agent.
Your goal is to gather high-quality information on a given topic and compile it into a dataset.

You have access to the following tools:
1. `search_internet(query)`: Finds relevant webpages.
2. `scrape_website(url)`: Reads the content of a specific webpage.
3. `save_to_dataset(topic, content, source_url)`: Saves formatted facts into the dataset.

Instructions:
- When given a topic, FIRST use `search_internet` to find sources.
- THEN use `scrape_website` to read the best URLs from the search results.
- Analyze the scraped content and identify distinct, valuable facts or findings.
- FINALLY, use `save_to_dataset` for EACH valuable fact you discover.
- Keep looping through tools until you have collected enough data (at least 3-5 distinct records if possible).
- When you are completely done collecting data, provide a brief summary of what you found and say "DATASET COLLECTION COMPLETE".
"""
        self.messages = [
            {"role": "system", "content": self.system_prompt}
        ]

    def run(self, topic: str):
        print(f"\n[Agent] Starting research on topic: '{topic}'")
        self.messages.append({"role": "user", "content": f"Please research '{topic}' and compile a dataset."})

        while True:
            try:
                # Ask the model what to do next
                response = self.client.chat(
                    model=self.model_name,
                    messages=self.messages,
                    tools=[search_internet, scrape_website, save_to_dataset]
                )
            except Exception as e:
                print(f"[Agent Error] Model communication failed: {e}")
                print("Make sure Ollama is running and the specified model is pulled (e.g., 'ollama run glm-5:cloud').")
                break

            # The response contains the model's message
            msg = response.get('message', {})
            self.messages.append(msg)

            # Check if the model decided to call any tools
            if msg.get('tool_calls'):
                for tool_call in msg['tool_calls']:
                    function_name = tool_call['function']['name']
                    arguments = tool_call['function']['arguments']
                    
                    print(f"\n[Agent] \033[94mCalling tool -> {function_name}({arguments})\033[0m")
                    
                    # Execute the tool
                    if function_name in self.available_tools:
                        tool_func = self.available_tools[function_name]
                        try:
                            # Parse JSON arguments if they come back as a str, otherwise use as dict
                            if isinstance(arguments, str):
                                args_dict = json.loads(arguments)
                            else:
                                args_dict = arguments
                                
                            tool_result = tool_func(**args_dict)
                        except Exception as e:
                            tool_result = f"Error executing {function_name}: {str(e)}"
                    else:
                        tool_result = f"Error: Tool '{function_name}' not found."

                    print(f"[Tool Output] \033[92m{str(tool_result)[:300]}...\033[0m")
                    
                    # Provide the tool result back to the model
                    self.messages.append({
                        "role": "tool",
                        "content": str(tool_result),
                        "name": function_name  # required to link result to tool call
                    })
            else:
                # If no tools were called, the agent is responding directly to the user
                content = msg.get('content', '')
                print(f"\n[Agent final report]:\n{content}")
                
                # Check for completion criteria
                if "DATASET COLLECTION COMPLETE" in content or "dataset collection complete" in content.lower():
                    print("\n[Agent] Mission accomplished.")
                    break
                else:
                    # Maybe it just answered, break to avoid infinite loop without tool calling
                    print("\n[Agent] Stopped iterating (no tools called).")
                    break
