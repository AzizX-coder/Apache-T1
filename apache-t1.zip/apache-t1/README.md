# Ollama Data Collection Agent

An autonomous research agent powered by Ollama that searches the internet, scrapes websites, and extracts structured data into a dataset. 

## Setup
### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Install and run Ollama
Download and install [Ollama](https://ollama.com/). You need a model that supports Tool Calling!

Pull a model:
```bash
ollama run glm-5:cloud
```

## Running the Agent

Start the agent CLI script:
```bash
python main.py --topic "Recent advances in quantum computing"
```

Or just run the script and it will prompt you:
```bash
python main.py
```

Optional arguments:
- `--model <model_name>`: Specify a different Ollama model (default is `glm-5:cloud`).

## Output
The agent writes the extracted facts into `dataset.jsonl` in the same directory. Each line is a separate JSON record containing:
- `topic`: The specific sub-topic or theme of the fact.
- `content`: The structured finding or content extracted.
- `source_url`: The URL from where the fact was derived.
